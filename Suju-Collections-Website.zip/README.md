# Suju Collections

Free static shopping website starter for Suju Collections.

## Pages
- `index.html` — customer shopping page
- `admin.html` — separate admin page

## Included
- Product search
- Cart and quantities
- Customer name, phone, address
- Google Maps location link using phone GPS permission
- PhonePe QR image
- WhatsApp order message to 9392916489
- Admin add/edit/delete products
- Price and stock management

## Important
This first version stores products in the browser's local storage. That means an admin change is not automatically shared with customers on other phones.

For true multi-device product syncing, a free backend (for example Google Apps Script/Sheets or Supabase) must be connected. The UI is ready for that next step.
