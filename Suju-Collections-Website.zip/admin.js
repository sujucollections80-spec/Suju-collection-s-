let products=JSON.parse(localStorage.getItem("sujuProducts")||"[]");
const KEY="sujuAdminPassword";
function loginAdmin(){const v=document.getElementById("adminPassword").value;if(v===(localStorage.getItem(KEY)||"suju1234")){sessionStorage.setItem("sujuAdmin","1");showAdmin()}else alert("Password తప్పు.");}
function showAdmin(){document.getElementById("loginBox").hidden=true;document.getElementById("adminPanel").hidden=false;renderAdmin()}
function logoutAdmin(){sessionStorage.removeItem("sujuAdmin");location.reload()}
function changePassword(){const v=document.getElementById("newPassword").value.trim();if(v.length<4)return alert("కనీసం 4 characters.");localStorage.setItem(KEY,v);alert("Password మార్చబడింది.");document.getElementById("newPassword").value=""}
function saveProducts(){localStorage.setItem("sujuProducts",JSON.stringify(products))}
function clearForm(){["editId","pName","pPrice","pStock","pCategory","pDesc","pImage"].forEach(id=>{const e=document.getElementById(id);if(e)e.value=""})}
function saveProduct(){
 const id=document.getElementById("editId").value||Date.now().toString(),name=document.getElementById("pName").value.trim(),price=Number(document.getElementById("pPrice").value),stock=Number(document.getElementById("pStock").value),cat=document.getElementById("pCategory").value.trim(),desc=document.getElementById("pDesc").value.trim(),file=document.getElementById("pImage").files[0];
 if(!name||!price)return alert("Product name, price పెట్టండి.");
 const old=products.find(p=>p.id===id)||{};const finish=(image)=>{const p={id,name,price,stock,category:cat,description:desc,image:image||old.image||"assets/logo.jpg"};const i=products.findIndex(x=>x.id===id);if(i>=0)products[i]=p;else products.push(p);saveProducts();clearForm();renderAdmin();alert("Product saved.");};
 if(file){const r=new FileReader();r.onload=()=>finish(r.result);r.readAsDataURL(file)}else finish();
}
function editProduct(id){const p=products.find(x=>x.id===id);if(!p)return;document.getElementById("editId").value=p.id;document.getElementById("pName").value=p.name;document.getElementById("pPrice").value=p.price;document.getElementById("pStock").value=p.stock;document.getElementById("pCategory").value=p.category||"";document.getElementById("pDesc").value=p.description||"";scrollTo({top:0,behavior:"smooth"})}
function deleteProduct(id){if(confirm("ఈ product delete చేయాలా?")){products=products.filter(x=>x.id!==id);saveProducts();renderAdmin()}}
function renderAdmin(){document.getElementById("adminProducts").innerHTML=products.length?products.map(p=>`<div class="admin-item"><img src="${p.image||'assets/logo.jpg'}"><div class="grow"><b>${p.name}</b><br>₹${p.price} • Stock ${p.stock}</div><button class="edit" onclick="editProduct('${p.id}')">Edit</button><button class="del" onclick="deleteProduct('${p.id}')">Delete</button></div>`).join(""):"No products yet."}
if(sessionStorage.getItem("sujuAdmin")==="1")showAdmin();
